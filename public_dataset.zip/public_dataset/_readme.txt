"ma15" refers to data processed by moving average of 15 points.
Other files are before moving average and the order of columns is x,y,z.